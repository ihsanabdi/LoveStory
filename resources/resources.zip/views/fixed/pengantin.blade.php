    <!--  ==========  -->
    <!--  = Pengantin =  -->
    <!--  ==========  -->
    <div class="most-popular blocks-spacer" id="wedding-intro">


        <div class="container">
        
          <div class="couple-info-wrapper">
            <div class="couple-container">
              <div class="couple-photo">
                <img alt="Groom Photo" src="images/groom-img.jpg">
              </div>
            </div>
            <div class="couple-photo-divider hidden-xs hidden-sm"></div>
            <div class="couple-container">
              <div class="couple-photo">
                <img alt="Bride Photo" src="images/bride-img.jpg">
              </div>
            </div>
          </div>
        </div>


    </div> <!-- /Pengantin -->