
    <style>
div.background {
    background: url(images/mutiara.jpg) no-repeat ;

    background-size: cover;
    border:  solid #fff;
    background-attachment: fixed;
}

div.transbox {
    margin: 30px;
    background-color: #FFF;
    opacity: 0.6;
    filter: alpha(opacity=60); /* For IE8 and earlier */
}

div.transbox p {
    margin: 5%;
    font-weight: bold;
    color: #D29F0C;
}
</style>

    <!--  ==========  -->
    <!--  = Quote =  -->
    <!--  ==========  -->
	<div class="container blocks-spacer-last">

		<!--  ==========  -->
		<!--  = Logos =  -->
		<!--  ==========  -->

        <div class="row">
            <div class="span12">
                <div class="brands  carouFredSel" data-nav="brands" data-autoplay="true">
                    <a href="http://www.proteusthemes.com/"><img src="images/dummy/brands/brands_01.jpg" alt="" width="203" height="104" /></a>
                    <a href="http://www.proteusthemes.com/"><img src="images/dummy/brands/brands_02.jpg" alt="" width="203" height="104" /></a>
                    <a href="http://www.proteusthemes.com/"><img src="images/dummy/brands/brands_03.jpg" alt="" width="203" height="104" /></a>
                    <a href="http://www.proteusthemes.com/"><img src="images/dummy/brands/brands_04.jpg" alt="" width="203" height="104" /></a>
                    <a href="http://www.proteusthemes.com/"><img src="images/dummy/brands/brands_05.jpg" alt="" width="203" height="104" /></a>
                    <a href="http://www.proteusthemes.com/"><img src="images/dummy/brands/brands_06.jpg" alt="" width="203" height="104" /></a>
                </div>
            </div>
        </div> <!-- /logos -->

	</div> <!-- /Quote -->

    
        <!--  ==========  -->
        <!--  = Upper footer =  -->
        <!--  ==========  -->
                    <div class="background">
  <div class="transbox"  style="color: #D29F0C;"><br><br>
    <center><h3><i>The Prophet Muhammad said "When a husband and wife look at each other with love, Allah looks at both of them with mercy".<br>
Shahih Bukhari 6:19 Tirmidhi</i></h3></center><br><br>
  </div>
</div>

        <!--  ==========  -->
        <!--  = Middle footer =  -->
        <!--  ==========  -->
        <div class="foot-dark">
        <div class="container">

            <!--  ==========  -->
            <!--  = Title =  -->
            <!--  ==========  -->
            <div class="row">
                <div class="span12">
                    <div class="main-titles center-align">
                        <h2 class="title">
                            <span class="clickable icon-chevron-left" id="tweetsLeft"></span> &nbsp;&nbsp;&nbsp;
                            <span class="light">Testimoni</span>  &nbsp;&nbsp;&nbsp;
                            <span class="clickable icon-chevron-right" id="tweetsRight"></span>
                        </h2>
                    </div>
                </div>
            </div> <!-- /title -->

            <!--  ==========  -->
            <!--  = News content =  -->
            <!--  ==========  -->
            <div class="row">
                <div class="span12">
                    <div class="carouFredSel" data-nav="tweets" data-autoplay="false">
                        
                        <!--  ==========  -->
                        <!--  = Slide = vvb  -->
                        <!--  ==========  -->
                        <div class="slide">
                            <div class="row">
                                <div class="span6">
                                    <div class="news-item">
                                        <h5>Title of the Latest News</h5>
                                        <p>There's a voice that keeps on calling me. Down the road, that's where I'll al ways be. Every stop I make, I make a new friend. Lorem sown the road, that's where I'll always be. Every stop I make, I make a new friend.</p>
                                    </div>
                                </div>
                                <div class="span6">
                                    <div class="news-item">
                                        <h5>Another Amusing News</h5>
                                        <p>There's a voice that keeps on calling me. Down the road, that's where I'll al ways be. Every stop I make, I make a new friend. Lorem sown the road, that's where I'll always be. Every stop I make, I make a new friend.</p>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- /slide -->
                        
                        <!--  ==========  -->
                        <!--  = Slide =  -->
                        <!--  ==========  -->
                        <div class="slide">
                            <div class="row">
                                <div class="span6">
                                    <div class="news-item">
                                        <h5>Title of the Latest News</h5>
                                        <p>There's a voice that keeps on calling me. Down the road, that's where I'll al ways be. Every stop I make, I make a new friend. Lorem sown the road, that's where I'll always be. Every stop I make, I make a new friend.</p>
                                    </div>
                                </div>
                                <div class="span6">
                                    <div class="news-item">
                                        <h5>Another Amusing News</h5>
                                        <p>There's a voice that keeps on calling me. Down the road, that's where I'll al ways be. Every stop I make, I make a new friend. Lorem sown the road, that's where I'll always be. Every stop I make, I make a new friend.</p>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- /slide -->
                                            </div>
                </div>
            </div> <!-- /news content -->
        </div>
    </div> <!-- /latest news -->

        </div> <!-- /middle footer -->