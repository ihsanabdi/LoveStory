
    <!--  ==========  -->
    <!--  = Service =  -->
    <!--  ==========  -->
    <div class="most-popular blocks-spacer">
        <div class="container">

            <div class="row popup-products">
                                
                <!--  ==========  -->
                <!--  = Product =  -->
                <!--  ==========  -->
                <div class="span4">
                    <div class="product">
                        <div class="product-inner">
                            <div class="product-img">
                                <div class="picture">
                                    <a href="#">
                                        <img src="images/dummy/most-popular-products/popular-1.jpg" alt="" width="540" height="412" />
                                    </a>
                                    <div class="img-overlay">
                                        <h2>Free Konsultasi</h2>
                                        <h2>Pernikahan</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- /product -->
                                
                <!--  ==========  -->
                <!--  = Product =  -->
                <!--  ==========  -->
                <div class="span4">
                    <div class="product">
                        <div class="product-inner">
                            <div class="product-img">
                                <div class="picture">
                                    <a href="#"><img src="images/dummy/most-popular-products/popular-2.jpg" alt="" width="540" height="412" /></a>
                                    <div class="img-overlay">
                                        <h2>Pernikahan</h2>
                                        <h2>Islami</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- /product -->
                                
                <!--  ==========  -->
                <!--  = Product =  -->
                <!--  ==========  -->
                <div class="span4">
                    <div class="product">
                        <div class="product-inner">
                            <div class="product-img">
                                <div class="picture">
                                    <a href="#"><img src="images/dummy/most-popular-products/popular-3.jpg" alt="" width="540" height="412" /></a>
                                    <div class="img-overlay">
                                        <h2>> 300 Vendor</h2>
                                        <h2>Se-Indonesia</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- /product -->
            </div>
        </div>
    </div> <!-- /Service -->