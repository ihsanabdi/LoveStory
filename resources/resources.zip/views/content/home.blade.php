@extends('layouts.index')

@section('title', 'Home')

@section('content')
	        
        @include('fixed.slider')

        @include('fixed.pengantin')

        @include('fixed.paket')

        @include('fixed.quote')
	
@endsection